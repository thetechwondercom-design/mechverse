MECHHUB V1

Open index.html in Chrome to view the website.

Current version:
- Responsive homepage
- Mechanical subject cards
- GATE section
- Practical engineering section
- Engineering tools section
- Career/interview section

Next build:
1. Real subject pages
2. Search
3. GATE question database
4. MCQ practice engine
5. Engineering calculators
6. User progress
7. Free deployment
